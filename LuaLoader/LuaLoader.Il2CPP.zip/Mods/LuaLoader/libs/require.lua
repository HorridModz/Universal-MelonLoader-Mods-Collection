JSON = require('JSON')
bit = require('funcs')