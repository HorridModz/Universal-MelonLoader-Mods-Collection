--[[
Example:

import('c# dll name','c# namespace')

You can put the c# dll in the same directory as the game exe
]]

-- Default
import('UnityEngine')
import('UnityEngine.UI')
import('PhotonRealtime','Photon.Realtime')
import('PhotonUnityNetworking','Photon.Pun')
import('UnhollowerBaseLib')
import('UnhollowerRuntimeLib')
import('UnhollowerBaseLib','UnhollowerRuntimeLib')
import('Assembly-CSharp')
import('Assembly-CSharp-firstpass')
import('System')
import('System','System.Type')
import('System.IO')
import('System.Runtime','System.Reflection')
import('0Harmony','HarmonyLib')

-- Custom